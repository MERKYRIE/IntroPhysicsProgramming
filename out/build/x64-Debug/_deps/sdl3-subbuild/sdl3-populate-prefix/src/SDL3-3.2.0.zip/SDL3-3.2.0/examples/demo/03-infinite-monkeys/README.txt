
How many monkeys does it take to write the complete works of Shakespeare?

    Now you can find out!

Cheer on your favorite monkey as they bash keyboards on their way through classic literature.

