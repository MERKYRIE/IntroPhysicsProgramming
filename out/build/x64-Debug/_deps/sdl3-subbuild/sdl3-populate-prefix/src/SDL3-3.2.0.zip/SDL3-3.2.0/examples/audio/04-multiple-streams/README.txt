If you're running this in a web browser, you need to click the window before you'll hear anything!

This example code loads two .wav files, puts them an audio streams and binds
them for playback, repeating both sounds on loop. This shows several streams
mixing into a single playback device.
