This example creates an SDL window and renderer, and then draws a something
roughly like a Christmas tree with nothing but lines, every frame.

